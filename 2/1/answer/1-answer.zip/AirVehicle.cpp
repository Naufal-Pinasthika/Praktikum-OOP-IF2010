#include "AirVehicle.hpp"

AirVehicle::AirVehicle(string vehicleId, string brand, int maxSpeed, int maxAltitude) : Vehicle(vehicleId, brand, maxSpeed), maxAltitude(maxAltitude) {
    cout << "[CREATE] AirVehicle " << brand << " at max altitude " << maxAltitude << "m ready\n";
}

AirVehicle::~AirVehicle() {
    cout << "[DELETE] AirVehicle " << brand <<" destroyed\n";    
}

string AirVehicle::getBrandName() const {
    return brand;
}

string AirVehicle::showSpec() const {
    return getSpec();
}

void AirVehicle::fly(string place) {
  cout << "[FLY] " << brand << " " << "(max " << maxAltitude << "m) flying to " << place << endl;     
}